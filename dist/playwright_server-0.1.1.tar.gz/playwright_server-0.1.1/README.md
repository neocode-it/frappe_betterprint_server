# Playwright Server

Python application for a web-based playwright browser (chromium is beeing used)

## Installing

Install UV

`curl -LsSf https://astral.sh/uv/install.sh | sh`

install playwright server using: 

uv tool install git+https://github.com/Neofix-IT/Playwright-Server/releases/latest/download/playwright_server_any.whl

installiert alles :-) crazy


https://docs.astral.sh/uv/guides/tools/#installing-tools


uv tool upgrade ruff