# Playwright Server

Python application for a web-based playwright browser (chromium is beeing used)

## Installing the tools using UV

Important: To use installed tools, ensure the tool bin directory is on the path:
```
# DOCKERFILE
ENV PATH=/root/.local/bin:$PATH
```
Reference: https://docs.astral.sh/uv/guides/integration/docker/#using-installed-tools

Install prerequesites

`apt-get update && apt-get install sudo git curl -y`

Install UV

`curl -LsSf https://astral.sh/uv/install.sh | sh && source $HOME/.cargo/env`

install playwright server using: 

`git clone https://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@github.com/Neofix-IT/Playwright-Server && uv tool install ./Playwright-Server/dist/*.whl`

Reference: https://docs.astral.sh/uv/guides/tools/#installing-tools


git clone https://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@github.com/Neofix-IT/Playwright-Server && sh ./Playwright-Server/install.sh



```
#!/bin/bash

# Install curl
apt-get update && apt-get install curl -y

# Run install script
source <(curl -s https://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@raw.githubusercontent.com/Neofix-IT/Playwright-Server/refs/heads/main/install.sh)

```